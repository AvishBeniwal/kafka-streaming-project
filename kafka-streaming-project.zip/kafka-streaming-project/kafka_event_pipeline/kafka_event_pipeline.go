package main

import (
	"bytes"
	"encoding/json"
	"flag"
	"fmt"
	"io"
	"log"
	"net/http"
	"time"

	"github.com/IBM/sarama"
	"github.com/gocql/gocql"
)

// We included these hostnames as they are a bit of a gotcha if you don't know that docker mapped these hostnames to the containers.
var (
	kafkaBrokers   = flag.String("kafka-brokers", "kafka:9092", "list of kafka brokers to connect to")
	apiHost        = flag.String("api-host", "http://api:8080", "api host to connect to")
	cassandraHosts = flag.String("cassandra-hosts", "cassandra:9042", "list of cassandra hosts to connect to")
)

// Message represents the structure of the Kafka message
type Message struct {
	CustomerID string `json:"customer_id"`
	Platform   string `json:"platform"`
	DataType   string `json:"data_type"`
	Data       string `json:"data"`
	SHA256     string `json:"sha256"`
}

type APIResponse map[string]interface{}

type CassandraClient struct {
	session *gocql.Session
}

type APIRequestBody struct {
	Data         string `json:"data"`
	PlatformType string `json:"platform_type"`
}

func main() {
	consumer, err := sarama.NewConsumer([]string{*kafkaBrokers}, nil)
	if err != nil {
		log.Fatalf("Failed to start Kafka consumer: %v", err)
	}
	defer consumer.Close()

	partitionConsumer, err := consumer.ConsumePartition("cs.sensor_events", 0, sarama.OffsetNewest)
	if err != nil {
		log.Fatalf("Failed to start partition consumer: %v", err)
	}
	defer partitionConsumer.Close()

	cassandraClient, err := NewClient()
	if err != nil {
		log.Fatalf("Failed to connect to Cassandra: %v", err)
	}
	defer cassandraClient.Close()

	for message := range partitionConsumer.Messages() {
		log.Printf("Received message new: %s", string(message.Value))

		var msg Message

		err := json.Unmarshal(message.Value, &msg)
		if err != nil {
			log.Printf("Failed to unmarshal message: %v", err)
			continue
		}

		apiResp, err := makeAPIRequest(msg.Data, msg.Platform)
		if err != nil {
			log.Printf("Failed to make API request: %v", err)
			continue
		}

		err = cassandraClient.Insert(msg.SHA256, apiResp)
		if err != nil {
			log.Printf("Failed to insert record in Cassandra: %v", err)
			continue
		}

	}
}

func NewClient() (*CassandraClient, error) {
	cluster := gocql.NewCluster(*cassandraHosts)
	cluster.Authenticator = gocql.PasswordAuthenticator{
		Username: "cassandra",
		Password: "cassandra",
	}
	cluster.Keyspace = "cs"
	session, err := cluster.CreateSession()
	if err != nil {
		return nil, err
	}
	return &CassandraClient{session: session}, nil
}

func (c *CassandraClient) Insert(key string, resp APIResponse) error {
	timeStamp := time.Now().Unix()
	return c.session.Query("INSERT INTO classification_results (sha256, maliciousness_score, classification, ts ) VALUES (?, ?, ?, ?)", key, resp["score"], resp["classification"], timeStamp).Exec()
}

func (c *CassandraClient) Close() {
	c.session.Close()
}

func makeAPIRequest(data, platform string) (APIResponse, error) {
	url := "http://api:8080/classify"

	reqd := &APIRequestBody{
		Data:         data,
		PlatformType: platform,
	}
	jsonStr, _ := json.Marshal(reqd)
	req, err := http.NewRequest("POST", url, bytes.NewBuffer(jsonStr))
	req.Header.Set("Content-Type", "application/json")

	client := &http.Client{}
	resp, err := client.Do(req)
	if err != nil {
		panic(err)
	}
	defer resp.Body.Close()

	fmt.Println("new response Status:", resp.Status)
	fmt.Println("response Headers:", resp.Header)
	body, _ := io.ReadAll(resp.Body)
	var apiResponse APIResponse
	fmt.Println("response new Body:", string(body))
	if err := json.Unmarshal(body, &apiResponse); err != nil {
		log.Printf("Failed to unmarshal api response %v", err)
		return nil, err
	}

	return apiResponse, nil
}
